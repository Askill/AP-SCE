%function accepts 3 double arrays (heights, radii, densities)
%passed arrays have to be of same size
%function returns a double value