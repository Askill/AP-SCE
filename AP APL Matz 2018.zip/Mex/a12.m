%function accepts 4 double arrays (heights, radii, densities, resistances)
%passed arrays have to be of same size
%function returns a double value