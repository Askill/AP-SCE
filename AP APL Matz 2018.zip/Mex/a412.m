% function accepts 1 double and 1 double matrix (#of_variables,increments, [x] , [y])
% each row1 contains #of_variables elements
% returns 2 vectors, xx and yy; yy being the interpolated y values
% bsp.:
%		    
%		[a1,a2]=a412(5,0.1,[1,2,3,4,5],[34,22,45,56,66])
