% function accepts 1 double and 2 vectors of double 
%		a611(#num_of_points, vector_a, vector_b)
% number of datapoints in both vectors must be equal, 
% or else the result will not be correct
% returns vector
