% function accepts 1 string and 3 doubles 
%		a621("function", interval_start, interval_end, precision)
%
%		a621 implements trapz (integral)
%
%exp.:	a621("sin",0,pi/2,0.000001)
%		ans = 1.0000