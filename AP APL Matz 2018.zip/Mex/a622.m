% function accepts 1 string and 3 doubles 
%		a622("function", interval_start, interval_end, precision)
%
%		a622 implements simpson quad (integral)
%
%exp.:	a622("sin",0,pi/2,0.000001)
%		ans = 1.0000