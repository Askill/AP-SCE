% function accepts 3 doubles 
%		a700(t0, t_end, x0)
%
%		a700 simulates the cooling of a fluid 
%
%exp.:	[a1,a2]=a752(0,10,100)
%		a1 = 0    1    2    3    4    5    6    7    8    9   10
%       a2 = 100.000    60.000    40.000    30.000    25.000    22.500    21.250    20.625    20.312    20.156    20.078